package com.example.cricket.model;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.Table;


@Entity
@Table(name="player")
public class PlayerModel {

	@Id
	public int player_id;
	public String player_name;
	public int run;
	public int ball;
	public String status;
	@ManyToOne(targetEntity = TeamModel.class, cascade = CascadeType.ALL)
	public TeamModel team;
	
	public PlayerModel() {
		
	}

	public PlayerModel(int player_id, String player_name, int run, int ball, String status, TeamModel team) {
		this.player_id = player_id;
		this.player_name = player_name;
		this.run = run;
		this.ball = ball;
		this.status = status;
		this.team = team;
	}

	public int getPlayer_id() {
		return player_id;
	}

	public void setPlayer_id(int player_id) {
		this.player_id = player_id;
	}

	public String getPlayer_name() {
		return player_name;
	}

	public void setPlayer_name(String player_name) {
		this.player_name = player_name;
	}

	public int getRun() {
		return run;
	}

	public void setRun(int run) {
		this.run = run;
	}

	public int getBall() {
		return ball;
	}

	public void setBall(int ball) {
		this.ball = ball;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public TeamModel getTeam() {
		return team;
	}

	public void setTeam(TeamModel team) {
		this.team = team;
	}
	
	
	
	
}
