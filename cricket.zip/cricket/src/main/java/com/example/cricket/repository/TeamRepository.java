package com.example.cricket.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.cricket.model.TeamModel;

public interface TeamRepository extends JpaRepository<TeamModel, Integer> {

}
