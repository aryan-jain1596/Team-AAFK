package com.example.cricket;

import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.context.request.WebRequest;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

@ControllerAdvice
public class CricketExceptionHandler extends ResponseEntityExceptionHandler  {

	@ExceptionHandler(value= {Exception.class})
	ResponseEntity<Object> handleError(Exception e, WebRequest req){
		String responseData="Data Error";
		return handleExceptionInternal(e, responseData,new HttpHeaders(), HttpStatus.PERMANENT_REDIRECT, req);
		
	}
}
