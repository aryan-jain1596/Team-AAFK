package com.example.cricket.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.cricket.repository.TeamRepository;

@Service
public class TeamService {

	@Autowired
	TeamRepository team;
}
