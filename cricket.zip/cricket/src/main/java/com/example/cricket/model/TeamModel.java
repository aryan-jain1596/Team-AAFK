package com.example.cricket.model;

import java.util.List;
import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;


@Entity
@Table(name="team")
public class TeamModel {

	@Id
	public int team_id;
	public String team_name;
	@OneToMany(cascade = CascadeType.ALL)
	public List<PlayerModel> player;
	
	public TeamModel() {
		
	}

	public TeamModel(int team_id, String team_name, List<PlayerModel> player) {
		this.team_id = team_id;
		this.team_name = team_name;
		this.player = player;
	}

	public int getTeam_id() {
		return team_id;
	}

	public void setTeam_id(int team_id) {
		this.team_id = team_id;
	}

	public String getTeam_name() {
		return team_name;
	}

	public void setTeam_name(String team_name) {
		this.team_name = team_name;
	}

	public List<PlayerModel> getPlayer() {
		return player;
	}

	public void setPlayer(List<PlayerModel> player) {
		this.player = player;
	}
	
}
