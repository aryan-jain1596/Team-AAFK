package com.example.cricket.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.cricket.model.PlayerModel;

public interface PlayerRepository extends JpaRepository<PlayerModel, Integer> {

}
