package com.example.cricket;

public class CricketController {

}
