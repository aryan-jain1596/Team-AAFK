package com.example.cricket;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CricketApplicationTests {

	@Test
	void contextLoads() {
	}

}
